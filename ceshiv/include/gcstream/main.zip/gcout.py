a = open('return.txt','w')
a.write('hello')
a.close()